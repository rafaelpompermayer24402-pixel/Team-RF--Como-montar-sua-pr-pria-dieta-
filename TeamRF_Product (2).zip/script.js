
function toNum(v){return Number(v)||0}
function calc() {
  const weight = toNum(document.getElementById('weight').value)
  const activity = toNum(document.getElementById('activity').value)
  const maintenance = Math.round(weight * 24 * activity)
  document.getElementById('maintenance').textContent = maintenance + ' kcal (estimado)'
  const goal = document.querySelector('input[name="goal"]:checked').value
  let delta = 0
  if(goal==='bulking') delta = 400
  if(goal==='cutting') delta = -400
  if(goal==='recomp') delta = 0
  const calories = maintenance + delta
  document.getElementById('targetCalories').textContent = calories + ' kcal'
  let prot = 2.0
  let carb = 4
  let fat = 0.9
  if(goal==='cutting'){ prot=2.2; carb=2.0; fat=0.7 }
  if(goal==='recomp'){ prot=2.1; carb=3.5; fat=0.8 }
  const pgrams = Math.round(prot * weight)
  const fgrams = Math.round(fat * weight)
  const cgrams = Math.round((calories - (pgrams*4 + fgrams*9))/4)
  document.getElementById('macros').innerHTML = 
     '<div class="small">Proteína: '+pgrams+' g ('+prot+' g/kg)</div>' +
     '<div class="small">Carboidrato: '+cgrams+' g</div>' +
     '<div class="small">Gordura: '+fgrams+' g</div>'
  const meals = generateMeals(pgrams, cgrams, fgrams)
  const mealsEl = document.getElementById('meals')
  mealsEl.innerHTML = ''
  meals.forEach(m=>{
    const d = document.createElement('div')
    d.className='meal'
    d.innerHTML='<strong>'+m.title+'</strong><div class="small">'+m.text+'</div>'
    mealsEl.appendChild(d)
  })
}

function generateMeals(p,c,f){
  const breakfastP = Math.round(p*0.3), breakfastC = Math.round(c*0.35)
  const lunchP = Math.round(p*0.28), lunchC = Math.round(c*0.3)
  const dinnerP = Math.round(p*0.28), dinnerC = Math.round(c*0.25)
  const snacksP = p - (breakfastP+lunchP+dinnerP)
  const snacksC = c - (breakfastC+lunchC+dinnerC)
  return [
    {title:'Café (Ex: ovos + aveia)', text: breakfastP+'g proteína • '+breakfastC+'g carb'},
    {title:'Almoço (Ex: arroz + frango)', text: lunchP+'g proteína • '+lunchC+'g carb'},
    {title:'Jantar (Ex: batata + carne)', text: dinnerP+'g proteína • '+dinnerC+'g carb'},
    {title:'Lanches', text: snacksP+'g proteína • '+snacksC+'g carb (2 lanches)'}
  ]
}

document.addEventListener('DOMContentLoaded', function(){
  document.getElementById('calcBtn').addEventListener('click', calc)
})
